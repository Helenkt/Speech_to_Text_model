@echo off
setlocal
set "PY=D:\UP\RUBRIC_ENGINE_V15_PACKAGE\.venv\Scripts\python.exe"
if not exist "%PY%" (
 echo Khong tim thay Python cua SDK: %PY%
 pause
 exit /b 1
)
"%PY%" "%~dp0app.py"
if errorlevel 1 pause
